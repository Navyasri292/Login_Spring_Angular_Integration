import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserdetailsComponent } from './adduserdetails.component';

describe('AddUserdetailsComponent', () => {
  let component: AddUserdetailsComponent;
  let fixture: ComponentFixture<AddUserdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adduserdetails',
  templateUrl: './adduserdetails.component.html',
  styleUrls: ['./adduserdetails.component.css']
})
export class AddUserdetailsComponent implements OnInit {
  login : Login = new Login();
  temp : Login = new Login();
  submitted=false;
  constructor(private service : LoginService,private router:Router) { }

  ngOnInit(): void {
  }
  addUserdetails()
  {
    console.log(this.login);
    this.service.addUserdetails(this.login).subscribe(data=>this.temp=data);
    this.router.navigate(['/','view']);
  }
  onSubmit() {
    this.submitted = true;
    this.addUserdetails();    
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddUserdetailsComponent } from './adduserdetails/adduserdetails.component';
import { ViewuserdetailsComponent } from './viewuserdetails/viewuserdetails.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { LogoutComponent } from './logout/logout.component';



const routes: Routes = [
  { 
    path  : 'signup',
    component : AddUserdetailsComponent
  },
  {
    path : 'view',
    component : ViewuserdetailsComponent
  },
  {
    path : 'login',
    component : UserloginComponent
  },
  {
    path : 'logout',
    component:LogoutComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from './login';
import { Userdetails } from 'src/userdetails';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  flag:boolean =false;
  url ="http://localhost:9090/userdetails/" ;

  constructor(private http : HttpClient ) {

  }

  

  getAllUserdetails() : Observable<HttpResponse<Login[]>>
  {
      return this.http.get<Login []>(this.url,{ observe: 'response' });
  }

  

  findUser(user_Name : string, password : string) : Observable<Login>
  {
    
    
    console.log("name = "+user_Name);
    //console.log("name= "+password);
    return this.http.get<Login>("http://localhost:9090/user/login/"+user_Name+"/"+password);
   
  }

  addUserdetails(login : Login ) : Observable<Login>
  {
    console.log("Service : "+login.user_Name);
    return this.http.post<Login>("http://localhost:9090/userdetails",login);
  }

  logout(user_Name:string) :Observable<Login>
  {
    console.log(user_Name);
   return this.http.put<Login>("http://localhost:9090/logout/"+user_Name,null);
   
  
  }

}

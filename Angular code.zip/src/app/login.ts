export class Login
{

    user_Name:string;
    password:string;
    phoneNum:number;
    emailId:string;
    role:string;
    status:number;

}
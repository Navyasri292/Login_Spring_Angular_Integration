import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private service:LoginService) { }

  ngOnInit(): void {
    
   this.logout();
  }
  logout()
  {
  var uname= sessionStorage.getItem("user_Name");
  if(uname)
  {
   this.service.logout(uname).subscribe(data=>alert("logout success"));
   alert(uname+"logged out succesfully");
  sessionStorage.removeItem("user_Name");
  }
   else{
     alert("please login");
   }
  }

}

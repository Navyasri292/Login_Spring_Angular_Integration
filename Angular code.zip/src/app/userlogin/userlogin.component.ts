import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';
import { Userdetails } from 'src/userdetails';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
 
  user_Name : string;
  password:"secret";
  show=false;
  login : Login = new Login();
  //login : Userdetails = new Userdetails();
  constructor(private service:LoginService,private router:Router) { }
  flag:boolean =false;

  ngOnInit(): void {
  }
  submitted=true;
  validate()
  {
    this.service.findUser(this.user_Name,this.password).subscribe(data=>{ sessionStorage.setItem("user_Name",data.user_Name);alert('login success')},error=>alert('login failed'));
    console.log(this.login.user_Name);
    console.log(this.user_Name);
   
       
   }   

   onSubmit() {
    this.submitted = true;
    this.validate();    
  }
  

  
 
// validate1()

//   {
//     this.service.findUser(this.user_Name,this.password).subscribe(data=>
//       {
        
//         setTimeout(()=>{this.login=data},500)
//       })
    
//     console.log(this.login.user_Name);
//     console.log(this.user_Name);
   
//     if((this.user_Name==this.login.user_Name)&&(this.password==this.login.password))
//     {
//        this.flag=true;

     
//         alert ('login success'); 
//         sessionStorage.setItem("user_Name",this.user_Name);
//        // console.log(sessionStorage.length);
//        // var users=sessionStorage.getItem("user_Name"+"password");
//        // sessionStorage.setItem("user_Name",this.user_Name);
       
//       // return this.service.findUser(this.user_Name,this.password).subscribe(data=>this.login=data)
//     }
//     else
//     {
//        alert('login failed \n Invalid username or password');
//     }



//     // this.router.navigate(['/','logout']);
//}
}

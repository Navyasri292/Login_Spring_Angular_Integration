import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAlluserdetailsComponent } from './viewuserdetails.component';

describe('ViewAlluserdetailsComponent', () => {
  let component: ViewAlluserdetailsComponent;
  let fixture: ComponentFixture<ViewAlluserdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAlluserdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAlluserdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

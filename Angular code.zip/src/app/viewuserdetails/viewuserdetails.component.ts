import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-viewuserdetails',
  templateUrl: './viewuserdetails.component.html',
  styleUrls: ['./viewuserdetails.component.css']
})
export class ViewuserdetailsComponent implements OnInit {
  arr : Login [] =[];
  logi : Login = new Login();

  constructor(private service : LoginService) 
  {
    service.getAllUserdetails().subscribe( data =>{this.arr = data.body;console.log(data);
    })

   }
   
  ngOnInit(): void {
  }

}

export class Userdetails
{
    user_Name:string;
    password:string;
    phoneNum:string;
    emailId:string;
    role:string;
    status:number;
}